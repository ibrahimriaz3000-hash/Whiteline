package com.dynamicpill.module;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** iOS style settings screen. Values are read live by System UI (about 2 seconds). */
public class MainActivity extends Activity {
    private static final int BLUE = 0xFF007AFF;
    private static final int GREEN = 0xFF34C759;
    private static final int BG = 0xFFF2F2F7;
    private static final int GRAY = 0xFF8E8E93;
    private static final int UNIT_MM = 0, UNIT_PCT = 1;

    private SharedPreferences sp;

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @SuppressWarnings({"deprecation", "WorldReadableFiles"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            sp = getSharedPreferences(PillController.PREF_FILE, Context.MODE_WORLD_READABLE);
        } catch (Throwable t) {
            sp = getSharedPreferences(PillController.PREF_FILE, Context.MODE_PRIVATE);
            Toast.makeText(this, "Activate the module in LSPosed first", Toast.LENGTH_LONG).show();
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(48), dp(16), dp(32));

        TextView title = new TextView(this);
        title.setText("Dynamic Pill");
        title.setTextSize(34);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(Color.BLACK);
        title.setPadding(dp(4), 0, 0, dp(4));
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Enable this module in LSPosed (scope: System UI), then reboot. "
                + "Changes apply live within about 2 seconds.");
        sub.setTextSize(13);
        sub.setTextColor(GRAY);
        sub.setPadding(dp(4), 0, dp(4), dp(8));
        root.addView(sub);

        // ---- Tiles info
        LinearLayout tiles = section(root, "CONTROL CENTER TILES");
        TextView tinfo = new TextView(this);
        tinfo.setText("Open Control Center, tap Edit, and add the \"Dynamic Pill\" and \"Pill Line\" "
                + "tiles. Tap a tile to turn it on or off. Long press a tile to open these settings.");
        tinfo.setTextSize(14);
        tinfo.setTextColor(Color.BLACK);
        tinfo.setPadding(dp(16), dp(12), dp(16), dp(12));
        tiles.addView(tinfo);

        // ---- Pill
        LinearLayout pill = section(root, "PILL");
        switchRow(pill, "Show pill", PillController.K_ENABLED, true);
        switchRow(pill, "Show on lock screen", PillController.K_LOCK, true);
        sliderRow(pill, "Width", PillController.K_WIDTH, PillController.D_WIDTH, 40, 300, 0, UNIT_MM);
        sliderRow(pill, "Height", PillController.K_HEIGHT, PillController.D_HEIGHT, 20, 120, 0, UNIT_MM);
        sliderRow(pill, "Vertical offset", PillController.K_YOFF, PillController.D_YOFF, 0, 200, -100, UNIT_MM);
        sliderRow(pill, "Opacity", PillController.K_ALPHA, 100, 0, 100, 0, UNIT_PCT);
        sliderRow(pill, "White border (0 = off)", PillController.K_BORDER, 4, 0, 20, 0, UNIT_MM);

        // ---- Line
        LinearLayout line = section(root, "LINE (iOS GRABBER)");
        switchRow(line, "Show line", PillController.K_LINE_ON, true);
        switchRow(line, "Smart hide (PIN screen, Control Center)", PillController.K_LINE_SMART, true);
        sliderRow(line, "Width", PillController.K_LINE_W, PillController.D_LINE_W, 30, 600, 0, UNIT_MM);
        sliderRow(line, "Thickness", PillController.K_LINE_H, 6, 2, 30, 0, UNIT_MM);
        sliderRow(line, "Center from right edge", PillController.K_LINE_X, PillController.D_LINE_X, 0, 700, 0, UNIT_MM);
        sliderRow(line, "Distance from top", PillController.K_LINE_Y, PillController.D_LINE_Y, 0, 300, 0, UNIT_MM);
        sliderRow(line, "Opacity", PillController.K_LINE_ALPHA, 70, 5, 100, 0, UNIT_PCT);
        TextView lnote = new TextView(this);
        lnote.setText("The line shows only on the lock screen. With Smart hide on, it also hides on the "
                + "PIN / pattern screen and when the shade is open. If the line ever does not show, "
                + "turn Smart hide off.");
        lnote.setTextSize(13);
        lnote.setTextColor(GRAY);
        lnote.setPadding(dp(16), dp(8), dp(16), dp(10));
        line.addView(lnote);

        // ---- Status bar padding
        LinearLayout bar = section(root, "STATUS BAR PADDING");
        sliderRow(bar, "Left", PillController.K_PAD_L, 0, 0, 200, 0, UNIT_MM);
        sliderRow(bar, "Right", PillController.K_PAD_R, 0, 0, 200, 0, UNIT_MM);
        sliderRow(bar, "Top", PillController.K_PAD_T, 0, 0, 200, 0, UNIT_MM);
        TextView bnote = new TextView(this);
        bnote.setText("Top makes the status bar taller, so icons move down without being cut off. "
                + "If it does not update right away, rotate the screen once or restart System UI.");
        bnote.setTextSize(13);
        bnote.setTextColor(GRAY);
        bnote.setPadding(dp(16), dp(8), dp(16), dp(10));
        bar.addView(bnote);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(sv);
    }

    private LinearLayout section(LinearLayout root, String name) {
        TextView h = new TextView(this);
        h.setText(name);
        h.setTextSize(12);
        h.setTextColor(GRAY);
        h.setPadding(dp(16), dp(20), 0, dp(6));
        root.addView(h);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.WHITE);
        g.setCornerRadius(dp(12));
        card.setBackground(g);
        root.addView(card, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return card;
    }

    private void divider(LinearLayout card) {
        if (card.getChildCount() == 0) return;
        View d = new View(this);
        d.setBackgroundColor(0xFFE5E5EA);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 1);
        lp.leftMargin = dp(16);
        card.addView(d, lp);
    }

    private void switchRow(LinearLayout card, String name, final String key, boolean def) {
        divider(card);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(10), dp(16), dp(10));

        TextView t = new TextView(this);
        t.setText(name);
        t.setTextSize(16);
        t.setTextColor(Color.BLACK);
        row.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Switch sw = new Switch(this);
        int[][] states = {{android.R.attr.state_checked}, {}};
        sw.setTrackTintList(new ColorStateList(states, new int[]{GREEN, 0xFFE5E5EA}));
        sw.setThumbTintList(ColorStateList.valueOf(Color.WHITE));
        sw.setChecked(sp.getBoolean(key, def));
        sw.setOnCheckedChangeListener((v, on) -> sp.edit().putBoolean(key, on).apply());
        row.addView(sw);
        card.addView(row);
    }

    /** value = progress + min + shift; mm sliders store 0.1 mm units. */
    private void sliderRow(LinearLayout card, final String name, final String key, int def,
                           final int min, int max, final int shift, final int unit) {
        divider(card);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(16), dp(10), dp(16), dp(6));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        TextView t = new TextView(this);
        t.setText(name);
        t.setTextSize(16);
        t.setTextColor(Color.BLACK);
        top.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final TextView val = new TextView(this);
        val.setTextSize(15);
        val.setTextColor(GRAY);
        top.addView(val);
        row.addView(top);

        int cur = sp.getInt(key, def);
        val.setText(fmt(cur, unit));

        SeekBar bar = new SeekBar(this);
        bar.setMax(max - min);
        bar.setProgress(cur - shift - min);
        bar.setProgressTintList(ColorStateList.valueOf(BLUE));
        bar.setThumbTintList(ColorStateList.valueOf(BLUE));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                int v = p + min + shift;
                val.setText(fmt(v, unit));
                if (user) sp.edit().putInt(key, v).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        row.addView(bar);
        card.addView(row);
    }

    private String fmt(int v, int unit) {
        return unit == UNIT_PCT ? v + " %" : (v / 10f) + " mm";
    }
}
